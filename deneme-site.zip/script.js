// ===== FIREBASE & SCOREBOARD =====
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.9.0/firebase-app.js";
import { getDatabase, ref, get, child, onValue, update, increment, query, orderByChild, limitToLast } from "https://www.gstatic.com/firebasejs/10.9.0/firebase-database.js";

const firebaseConfig = {
    apiKey: "AIzaSyA9J0vBh5JJ_1FFKFOhZTQ4h5PaL0UwMx0",
    authDomain: "aminake-b8df8.firebaseapp.com",
    databaseURL: "https://aminake-b8df8-default-rtdb.firebaseio.com",
    projectId: "aminake-b8df8",
    storageBucket: "aminake-b8df8.firebasestorage.app",
    messagingSenderId: "321291923055",
    appId: "1:321291923055:web:d2ab056bbcfaa2df93279a",
    measurementId: "G-18V4WVSKPM"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);

// ===== INTRO SEQUENCE =====
// İlk ziyarette kısa bir geri sayım gösterilir, sonraki ziyaretlerde atlanır.
(function intro() {
    const overlay = document.getElementById('intro-overlay');
    const mainContent = document.getElementById('main-content');
    if (!overlay) return;

    const ac = () => {
        overlay.classList.add('fade-out');
        mainContent.classList.remove('hidden');
        mainContent.classList.add('visible');
        setTimeout(() => overlay.remove(), 800);
        try { localStorage.setItem('aminake-intro', '1'); } catch (_) { }
    };

    if (document.documentElement.classList.contains('intro-yok')) {
        overlay.remove();
        mainContent.classList.remove('hidden');
        return;
    }

    const lines = [1, 2, 3, 4, 5].map(i => document.getElementById('line' + i));
    const ADIM = 600; // her satır 0,6 sn (eskiden 1 sn)
    const zamanlayicilar = [];
    lines.forEach((line, i) => {
        zamanlayicilar.push(setTimeout(() => {
            if (i > 0) lines[i - 1].classList.replace('show', 'hide');
            line.classList.add('show');
        }, 200 + i * ADIM));
    });
    zamanlayicilar.push(setTimeout(() => lines[4].classList.replace('show', 'hide'), 200 + 5 * ADIM));
    zamanlayicilar.push(setTimeout(ac, 200 + 5 * ADIM + 300));

    document.getElementById('intro-gec').addEventListener('click', () => {
        zamanlayicilar.forEach(clearTimeout);
        ac();
    });
})();

// ===== PARTICLE SYSTEM =====
const canvas = document.getElementById('particle-canvas');
const ctx = canvas.getContext('2d');
let particles = [];

function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}
window.addEventListener('resize', resizeCanvas);
resizeCanvas();

class Particle {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        const angle = Math.random() * Math.PI * 2;
        const speed = Math.random() * 8 + 3;
        this.vx = Math.cos(angle) * speed;
        this.vy = Math.sin(angle) * speed;
        this.life = 1;
        this.decay = Math.random() * 0.02 + 0.015;
        this.size = Math.random() * 6 + 2;
        const colors = ['#ff2d95', '#00f0ff', '#b829dd', '#39ff14', '#ffdd00'];
        this.color = colors[Math.floor(Math.random() * colors.length)];
        this.gravity = 0.08;
    }

    update() {
        this.x += this.vx;
        this.y += this.vy;
        this.vy += this.gravity;
        this.vx *= 0.99;
        this.life -= this.decay;
    }

    draw() {
        ctx.save();
        ctx.globalAlpha = this.life;
        ctx.fillStyle = this.color;
        ctx.shadowColor = this.color;
        ctx.shadowBlur = 15;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size * this.life, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
    }
}

function spawnParticles(x, y, count = 50) {
    for (let i = 0; i < count; i++) {
        particles.push(new Particle(x, y));
    }
}

function animateParticles() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles = particles.filter(p => p.life > 0);
    particles.forEach(p => {
        p.update();
        p.draw();
    });
    requestAnimationFrame(animateParticles);
}
animateParticles();

// ===== SOUND + PITCH SYSTEM (WEB AUDIO API - ZERO LATENCY) =====
const AudioContext = window.AudioContext || window.webkitAudioContext;
let audioCtx;
let audioBuffer = null;

// AudioContext oluştur ve dosyayı belleğe yükle
function initAudio() {
    if (!audioCtx) {
        audioCtx = new AudioContext();
    }
    fetch('/aminake.mp3')
        .then(response => response.arrayBuffer())
        .then(data => audioCtx.decodeAudioData(data))
        .then(buffer => {
            audioBuffer = buffer;
            console.log('✅ aminake.mp3 belleğe yüklendi (0 Gecikme)');
        })
        .catch(err => console.log('⚠️ Ses yüklenemedi:', err));
}
// Sayfa açıldığında çekmeye başla
initAudio();

let currentPitch = 1.0;
const PITCH_INCREMENT = 0.15;
const MAX_PITCH = 3.5;

let countdownInterval = null;
let remainingResetTime = 0;
const pitchTimerEl = document.getElementById('pitch-timer');
const pitchTimeSpan = document.getElementById('pitch-time');

function resetPitch() {
    pitchTimerEl.classList.add('hidden');
    const resetInterval = setInterval(() => {
        currentPitch -= 0.05;
        if (currentPitch <= 1.0) {
            currentPitch = 1.0;
            clearInterval(resetInterval);
        }
    }, 30);
}

function playSound() {
    // İlk tıklamada AudioContext başlatılıyorsa resume et (Tarayıcı politikaları)
    if (!audioCtx) initAudio();
    if (audioCtx && audioCtx.state === 'suspended') {
        audioCtx.resume();
    }

    currentPitch = Math.min(currentPitch + PITCH_INCREMENT, MAX_PITCH);

    if (countdownInterval) clearInterval(countdownInterval);

    if (currentPitch > 1.05) {
        pitchTimerEl.classList.remove('hidden');
        remainingResetTime = 3;
        pitchTimeSpan.textContent = remainingResetTime;

        countdownInterval = setInterval(() => {
            remainingResetTime--;
            if (remainingResetTime > 0) {
                pitchTimeSpan.textContent = remainingResetTime;
            } else {
                clearInterval(countdownInterval);
                resetPitch();
            }
        }, 1000);
    }

    // Gecikmesiz çalma!
    if (audioBuffer && audioCtx) {
        const source = audioCtx.createBufferSource();
        source.buffer = audioBuffer;
        source.playbackRate.value = currentPitch;
        source.connect(audioCtx.destination);
        source.start(0);
    } else {
        playSynthFallback();
    }
}

// Fallback sentez ses (mp3 yoksa)
function playSynthFallback() {
    if (!audioCtx) initAudio();
    if (audioCtx && audioCtx.state === 'suspended') {
        audioCtx.resume();
    }

    const now = audioCtx.currentTime;
    const p = currentPitch;

    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(120 * p, now);
    osc.frequency.exponentialRampToValueAtTime(60 * p, now + 0.4 / p);
    gain.gain.setValueAtTime(0.4, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5 / p);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start(now);
    osc.stop(now + 0.5 / p);
}

// DOM Elements
const authContainer = document.getElementById('auth-container');
const loggedInContainer = document.getElementById('logged-in-container');
const usernameInput = document.getElementById('username-input');
const joinBtn = document.getElementById('join-btn');
const currentUsernameSpan = document.getElementById('current-username');
const leaderboardList = document.getElementById('leaderboard-list');
const counterEl = document.getElementById('counter-value');
const counterContainer = document.getElementById('counter-container');

// Auth: Kullanıcı adı kontrolü
// Sadece harf, rakam ve alt çizgi. Firebase yolunu bozan / . # $ [ ] karakterleri
// ve HTML enjeksiyonu bu sayede engellenir. (Aynı kural database.rules.json'da da var.)
const ISIM_KURALI = /^[A-Za-z0-9_çğıöşüÇĞİÖŞÜ]{1,12}$/;

let currentUser = null;
try { currentUser = localStorage.getItem('aminake-username'); } catch (_) { }
if (currentUser && !ISIM_KURALI.test(currentUser)) {
    // Eski sürümde kurala uymayan isim alınmışsa sıfırla
    currentUser = null;
    try { localStorage.removeItem('aminake-username'); } catch (_) { }
}

if (currentUser) {
    showLoggedIn(currentUser);
}

joinBtn.addEventListener('click', async () => {
    const val = usernameInput.value.trim();
    if (val.length === 0) return;
    if (!ISIM_KURALI.test(val)) {
        alert('Takma ad 1–12 karakter olmalı ve sadece harf, rakam ve alt çizgi (_) içermeli.');
        return;
    }
    
    // Disable input while checking
    usernameInput.disabled = true;
    joinBtn.disabled = true;
    joinBtn.textContent = 'Kontrol ediliyor...';

    try {
        const userRef = child(ref(db), `users/${val}`);
        const snapshot = await get(userRef);
        
        if (snapshot.exists()) {
            // Eğer veritabanında varsa o isim kullanımdadır.
            alert(`"${val}" ismi başka bir efsane tarafından alınmış! Lütfen farklı bir isim dene.`);
        } else {
            // Kimse almamışsa, başarıyla oturum aç
            currentUser = val;
            try { localStorage.setItem('aminake-username', currentUser); } catch (_) { }
            showLoggedIn(currentUser);
        }
    } catch (err) {
        console.error(err);
        alert('Sunucu hatası. Sonra tekrar dene.');
    } finally {
        usernameInput.disabled = false;
        joinBtn.disabled = false;
        joinBtn.textContent = 'Sıralamaya Katıl';
    }
});

function showLoggedIn(name) {
    authContainer.classList.add('hidden');
    loggedInContainer.classList.remove('hidden');
    currentUsernameSpan.textContent = name;
}

// Global Durum
let globalClickCount = parseInt(counterEl.textContent.replace(/\./g, '')) || 0;
let pendingSyncClicks = 0;

// 1. Dinleyici: Global Toplam Sayı
onValue(ref(db, 'global/count'), (snapshot) => {
    const serverCount = snapshot.val() || 0;
    // Eğer sunucu + bekleyenler bizim yerelden büyükse eşitle
    if (serverCount + pendingSyncClicks > globalClickCount) {
        globalClickCount = serverCount + pendingSyncClicks;
    }
    counterEl.textContent = globalClickCount.toLocaleString('tr-TR');
});

// 2. Dinleyici: Canlı Skorboard (En çok basan 10 kişi)
const topUsersQuery = query(ref(db, 'users'), orderByChild('score'), limitToLast(5));
onValue(topUsersQuery, (snapshot) => {
    const users = [];
    snapshot.forEach((childSnap) => {
        users.push({
            name: childSnap.key,
            score: childSnap.val().score
        });
    });

    // Puanları büyükten küçüğe sıralamak için ters çevir (limitToLast artan verir)
    users.reverse();

    leaderboardList.innerHTML = '';
    if (users.length === 0) {
        leaderboardList.innerHTML = '<li class="loading">Liste boş!</li>';
        return;
    }

    users.forEach(u => {
        // innerHTML KULLANMA: isimler kullanıcıdan geliyor, HTML olarak basılırsa
        // herkesin tarayıcısında kod çalıştırılabilir (XSS).
        const li = document.createElement('li');
        const ad = document.createElement('span');
        ad.className = 'lb-name';
        ad.textContent = u.name;
        const skor = document.createElement('span');
        skor.className = 'lb-score';
        skor.textContent = Number(u.score || 0).toLocaleString('tr-TR');
        li.append(ad, skor);
        leaderboardList.appendChild(li);
    });
});

// 3. Veritabanına Yollayıcı (Toplu Batched Update)
// 1.5 saniyede bir bekleyen tıklamaları Firebase'e yollar
setInterval(() => {
    if (pendingSyncClicks > 0) {
        // Firebase kuralı tek seferde en fazla 100 artışa izin veriyor
        const clicksToSend = Math.min(pendingSyncClicks, 90);
        pendingSyncClicks -= clicksToSend;

        const updates = {};
        updates['global/count'] = increment(clicksToSend);

        if (currentUser) {
            updates[`users/${currentUser}/score`] = increment(clicksToSend);
        }

        update(ref(db), updates).catch(err => {
            console.error("Firebase sync hatası", err);
            pendingSyncClicks += clicksToSend; // Hata olursa geri al
        });
    }
}, 1500);

function incrementCounter() {
    // Ekranda anında güncelle (Live Update)
    globalClickCount++;
    pendingSyncClicks++;
    counterEl.textContent = globalClickCount.toLocaleString('tr-TR');

    // Animasyon
    counterContainer.classList.remove('bump');
    void counterContainer.offsetWidth; // reflow
    counterContainer.classList.add('bump');
}

// ===== SCREEN SHAKE =====
function shakeScreen() {
    document.body.classList.remove('shake');
    void document.body.offsetWidth;
    document.body.classList.add('shake');
    setTimeout(() => document.body.classList.remove('shake'), 500);
}

// ===== FLASH EFFECT =====
function flashScreen() {
    const flash = document.createElement('div');
    flash.className = 'flash-overlay';
    document.body.appendChild(flash);
    setTimeout(() => flash.remove(), 500);
}

// ===== FLOATING TEXT =====
const floatingTexts = [
    'AMINAKE!', 'OOFFF', 'SÖYLEDİM Bİ DE YA!', 'EVRİMMİŞ',
    'İNANAMIYORUM!', 'PATLADI!', 'AHAHAHAHA', 'YOK ARTIK!',
    'GÜMBÜR!', '🤯', 'DAYIII!', 'HAYDAAA'
];

function spawnFloatingText(x, y) {
    const el = document.createElement('div');
    el.className = 'floating-text';
    el.textContent = floatingTexts[Math.floor(Math.random() * floatingTexts.length)];
    el.style.left = (x + (Math.random() - 0.5) * 100) + 'px';
    el.style.top = (y - 30) + 'px';
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 1500);
}

// ===== RANDOM BG COLOR FLASH =====
function flashBgColor() {
    const colors = [
        'radial-gradient(circle at center, rgba(255,45,149,0.15), transparent 70%)',
        'radial-gradient(circle at center, rgba(0,240,255,0.15), transparent 70%)',
        'radial-gradient(circle at center, rgba(184,41,221,0.15), transparent 70%)',
        'radial-gradient(circle at center, rgba(57,255,20,0.15), transparent 70%)',
    ];
    const bg = colors[Math.floor(Math.random() * colors.length)];
    document.body.style.background = bg + ', var(--dark-bg)';
    setTimeout(() => {
        document.body.style.background = 'var(--dark-bg)';
    }, 300);
}

// ===== VADAA CHARACTERS =====
function spawnVada() {
    const el = document.createElement('img');
    el.src = '/vada.webp';
    el.alt = '';
    el.className = 'vada-character';

    // Vary the speed, size, and vertical position a bit
    const duration = 2.5 + Math.random() * 3; // 2.5s to 5.5s
    const width = 80 + Math.random() * 100; // 80px to 180px
    const bottomPos = 1 + Math.random() * 20; // randomly between 1% and 21% from bottom

    el.style.animationDuration = `${duration}s, 0.3s`;
    el.style.width = `${width}px`;
    el.style.bottom = `${bottomPos}%`;

    // Randomize whether it bounces in sync or differently
    el.style.animationDelay = `0s, ${Math.random() * 0.3}s`;

    document.body.appendChild(el);
    setTimeout(() => el.remove(), duration * 1000);
}

// Periodically spawn a vadaa randomly
setInterval(() => {
    if (Math.random() > 0.6) {
        spawnVada();
    }
}, 2000);

// ===== MAIN BUTTON CLICK =====
const btn = document.getElementById('aminake-btn');

btn.addEventListener('click', (e) => {
    const rect = btn.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;

    // All the effects!
    playSound();
    shakeScreen();
    flashScreen();
    flashBgColor();
    spawnParticles(cx, cy, 60);
    spawnFloatingText(cx, cy);
    incrementCounter();
    spawnVada(); // Spawn a Vada on every click!

    // Extra particles from random spots for chaos
    for (let i = 0; i < 2; i++) {
        setTimeout(() => {
            spawnParticles(
                Math.random() * window.innerWidth,
                Math.random() * window.innerHeight,
                20
            );
        }, i * 100);
    }
});

// Allow rapid clicking
btn.addEventListener('mousedown', (e) => e.preventDefault());
